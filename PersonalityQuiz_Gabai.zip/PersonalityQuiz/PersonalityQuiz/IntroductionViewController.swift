//
//  IntroductionViewController.swift
//  PersonalityQuiz
//
//  Created by Nicholas Gabai on 11/6/22.
//
//On my honor, I have neither received nor given any unauthorized assistance on this Final Assignment. - Nicholas Gabai

import UIKit

class IntroductionViewController: UIViewController {

    @IBAction func unwind(segue: UIStoryboardSegue){
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

